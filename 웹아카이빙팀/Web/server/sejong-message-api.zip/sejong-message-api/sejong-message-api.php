<?php
/**
 * Plugin Name: Sejong Message API
 * Description: 졸업전시 MESSAGE 페이지용 공개 REST API (GET/POST)와 전용 DB 테이블을 제공합니다.
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

define('SEJONG_MESSAGE_API_VERSION', '1.0.0');

function sejong_message_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'sejong_messages';
}

function sejong_message_api_activate() {
    global $wpdb;

    $table_name = sejong_message_table_name();
    $charset_collate = $wpdb->get_charset_collate();

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $sql = "CREATE TABLE {$table_name} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        nickname varchar(20) NOT NULL,
        message varchar(300) NOT NULL,
        created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY created_at (created_at)
    ) {$charset_collate};";

    dbDelta($sql);
}
register_activation_hook(__FILE__, 'sejong_message_api_activate');

function sejong_message_api_cors() {
    $origin = isset($_SERVER['HTTP_ORIGIN']) ? esc_url_raw($_SERVER['HTTP_ORIGIN']) : '';

    $allowed_origins = array(
        'https://yangjunho-m.github.io',
    );

    // sj-di.com으로 프론트를 이전했을 때도 동작하도록 허용.
    if ($origin === 'http://sj-di.com' || $origin === 'https://sj-di.com') {
        $allowed_origins[] = $origin;
    }

    if ($origin && in_array($origin, $allowed_origins, true)) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Vary: Origin');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');
    }
}
add_action('rest_api_init', 'sejong_message_api_cors', 5);

function sejong_message_api_register_routes() {
    register_rest_route('sejong/v1', '/messages', array(
        array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => 'sejong_message_get_messages',
            'permission_callback' => '__return_true',
        ),
        array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => 'sejong_message_create_message',
            'permission_callback' => '__return_true',
        ),
    ));
}
add_action('rest_api_init', 'sejong_message_api_register_routes');

function sejong_message_get_messages(WP_REST_Request $request) {
    global $wpdb;

    $table_name = sejong_message_table_name();

    $rows = $wpdb->get_results(
        "SELECT id, nickname, message, created_at
         FROM {$table_name}
         ORDER BY created_at DESC, id DESC
         LIMIT 200",
        ARRAY_A
    );

    if ($rows === null && !empty($wpdb->last_error)) {
        return new WP_Error(
            'sejong_db_error',
            '메시지를 불러오지 못했습니다.',
            array('status' => 500)
        );
    }

    return rest_ensure_response($rows ?: array());
}

function sejong_message_create_message(WP_REST_Request $request) {
    global $wpdb;

    $params = $request->get_json_params();
    if (!is_array($params)) {
        $params = $request->get_params();
    }

    $nickname = isset($params['nickname']) ? sanitize_text_field($params['nickname']) : '';
    $message = isset($params['message']) ? sanitize_textarea_field($params['message']) : '';

    $nickname = trim($nickname);
    $message = trim($message);

    if ($nickname === '' || $message === '') {
        return new WP_Error(
            'sejong_required_fields',
            '닉네임과 메시지를 모두 입력해주세요.',
            array('status' => 400)
        );
    }

    if (mb_strlen($nickname, 'UTF-8') > 20) {
        return new WP_Error(
            'sejong_nickname_too_long',
            '닉네임은 20자 이하로 입력해주세요.',
            array('status' => 400)
        );
    }

    if (mb_strlen($message, 'UTF-8') > 300) {
        return new WP_Error(
            'sejong_message_too_long',
            '메시지는 300자 이하로 입력해주세요.',
            array('status' => 400)
        );
    }

    // 공개 방명록의 최소한의 도배 방지: 같은 IP는 5초 내 연속 등록 불가.
    $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
    $rate_key = 'sejong_msg_' . md5($ip);

    if (get_transient($rate_key)) {
        return new WP_Error(
            'sejong_rate_limited',
            '잠시 후 다시 등록해주세요.',
            array('status' => 429)
        );
    }

    $table_name = sejong_message_table_name();
    $inserted = $wpdb->insert(
        $table_name,
        array(
            'nickname' => $nickname,
            'message' => $message,
            'created_at' => current_time('mysql'),
        ),
        array('%s', '%s', '%s')
    );

    if ($inserted === false) {
        return new WP_Error(
            'sejong_db_error',
            '메시지를 저장하지 못했습니다.',
            array('status' => 500)
        );
    }

    set_transient($rate_key, 1, 5);

    $response = array(
        'id' => (int) $wpdb->insert_id,
        'nickname' => $nickname,
        'message' => $message,
        'created_at' => current_time('mysql'),
    );

    return new WP_REST_Response($response, 201);
}
